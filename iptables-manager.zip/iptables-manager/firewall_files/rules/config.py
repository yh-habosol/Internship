OEM_LOG = {
    "JLR": {
        "Mismatch_MAC_ADDR": "UDP_SPOOFED_PACKET",
        "Mismatch_IP_ADDR": "TCPIP_SEV_DROP_INV_IP4_ADDR",
        "Mismatch_TCP_PORT": "TCPIP_SEV_DROP_INV_PORT_TCP",
        "Mismatch_UDP_PORT": "TCPIP_SEV_DROP_INV_PORT_UDP",
    }
    # List logging conditions from other OEMs
    # example: hyundai, toyota..
}
